# include <memory>
# include <unordered_map>
# include "flight_trip.h"

/** Flight Management System*/
namespace FlightManagementSystem
{
	class FlightTripDatabase
	{
		public:
		/** Constructor(S)*/
		FlightTripDatabase();
  
		/** Suitable prototypes/defintions for the expected functionality*/
		void AddTrip(const std::string flight_number, const std::string origin_city, 
		const std::string destination_city, const std::string flight_operator, float air_fare);
		void RemoveTrip(const std::string flight_number);
		void DisplayAllTrips();
		// ---------- yet to implement ------------------------ //
		void UpdateFareByTrip(const FlightTrip& f_trip);		
		void FindFlightByNumber(const FlightTrip& f_trip);
		void FindFlightsByOriginCity(const FlightTrip& f_trip);
		void FindAverageCostOfAllTrips();
		void FindMinFareBetweenCities(const FlightTrip& f_trip);
		void FindMaxFareByOperator(const FlightTrip& f_trip);
		void UpdateFareByOperator(const FlightTrip& f_trip);
  
		/** Return the results wherver possible, let's not leave by just printing*/

		private:
		/** Suitable container */
		std::unordered_map<std::string, std::shared_ptr<FlightTrip>> trip_map;
	};
}